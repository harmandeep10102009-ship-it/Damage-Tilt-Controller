package com.example.damagetilt;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v1.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v1.ClientCommandRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.LiteralText;

import static net.fabricmc.fabric.api.client.command.v1.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v1.ClientCommandManager.literal;

import com.mojang.brigadier.arguments.FloatArgumentType;

/**
 * Client-side mod initializer.
 * Registers a simple client command:
 *   /damagetilt <0-100>   -> sets the tilt strength percentage
 *   /damagetilt           -> prints the current value
 */
public class DamageTiltMod implements ClientModInitializer {

    public static final String MOD_ID = "damagetilt";

    @Override
    public void onInitializeClient() {
        DamageTiltConfig.get(); // ensure config is loaded on startup

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(literal("damagetilt")
                .executes(context -> {
                    float current = DamageTiltConfig.get().tiltPercent;
                    MinecraftClient.getInstance().player.sendMessage(
                            new LiteralText("Damage tilt is currently set to " + current + "%"), false);
                    return 1;
                })
                .then(argument("percent", FloatArgumentType.floatArg(0, 100))
                    .executes(context -> {
                        float percent = FloatArgumentType.getFloat(context, "percent");
                        DamageTiltConfig.get().setTiltPercent(percent);
                        MinecraftClient.getInstance().player.sendMessage(
                                new LiteralText("Damage tilt set to " + percent + "%"), false);
                        return 1;
                    })
                )
            );
        });
    }
}
