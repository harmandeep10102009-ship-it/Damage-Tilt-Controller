package com.example.damagetilt;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Holds the damage tilt strength as a percentage (0 - 100).
 * 0   = no screen shake/tilt when taking damage
 * 100 = vanilla default tilt strength
 * Values above 100 can be set programmatically for an exaggerated effect.
 */
public class DamageTiltConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("damagetilt.json");

    // Percentage value: 0 - 100 (clamped in setter)
    public float tiltPercent = 100.0F;

    private static DamageTiltConfig instance;

    public static DamageTiltConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    /** Returns the tilt strength as a multiplier (0.0 - 1.0+) for use in the mixin. */
    public float getTiltMultiplier() {
        return tiltPercent / 100.0F;
    }

    public void setTiltPercent(float percent) {
        if (percent < 0.0F) percent = 0.0F;
        if (percent > 100.0F) percent = 100.0F;
        this.tiltPercent = percent;
        save();
    }

    private static DamageTiltConfig load() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                try (FileReader reader = new FileReader(CONFIG_PATH.toFile())) {
                    DamageTiltConfig loaded = GSON.fromJson(reader, DamageTiltConfig.class);
                    if (loaded != null) {
                        return loaded;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        DamageTiltConfig fresh = new DamageTiltConfig();
        fresh.save();
        return fresh;
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (FileWriter writer = new FileWriter(CONFIG_PATH.toFile())) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
