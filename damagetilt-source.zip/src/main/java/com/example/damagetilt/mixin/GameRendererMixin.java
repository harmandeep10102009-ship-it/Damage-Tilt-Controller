package com.example.damagetilt.mixin;

import com.example.damagetilt.DamageTiltConfig;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.math.Quaternion;
import net.minecraft.util.math.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Redirects the call to Vector3f.getDegreesQuaternion(float) inside
 * GameRenderer#tiltViewWhenHurt, scaling the rotation angle by the
 * configured damage tilt percentage (0.0 - 1.0+ multiplier).
 *
 * Vanilla behaviour is preserved exactly when the config is at 100%.
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Redirect(
        method = "tiltViewWhenHurt",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/util/math/Vector3f;getDegreesQuaternion(F)Lnet/minecraft/util/math/Quaternion;"
        )
    )
    private Quaternion damagetilt$scaleTilt(Vector3f vector3f, float degrees) {
        float multiplier = DamageTiltConfig.get().getTiltMultiplier();
        return vector3f.getDegreesQuaternion(degrees * multiplier);
    }
}
